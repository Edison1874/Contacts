//
//  FactoryUI.m
//  Kitchen
//
//  Created by fq on 15/11/5.
//  Copyright (c) 2015年 fangqian. All rights reserved.
//

#import "FactoryUI.h"

@implementation FactoryUI
+(UIBarButtonItem *)CreateProjectTitleBBI
{
    UILabel * TitleLabel=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, 240, 30)];
    TitleLabel.text=@"优购-全球最潮的购物平台";
    TitleLabel.textColor=[UIColor whiteColor];
    TitleLabel.font=[UIFont systemFontOfSize:12];
    
    UIBarButtonItem * titleBBI=[[UIBarButtonItem alloc]initWithCustomView:TitleLabel];
    
    return titleBBI;

}

//创建用来调整位置的一个占位的BBI
//@param width  这个参数就是你要调整的宽度，可以为负数，负数就是向相反方向调整
+(UIBarButtonItem *)CreateSpaceBBIWidth:(CGFloat)width{
    UIBarButtonItem * spaceBBI=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    spaceBBI.width=width;
    return spaceBBI;
   
}

//创建应用返回的BBI
// @param  target 事件的目标对象  @param action 事件函数
+(UIBarButtonItem *)CreateBackBBIWithTarget:(id)target action:(SEL)action{
    //创建一个容器来承载返回的图片和分割线
    UIView * bgview=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 50, 44)];
    //返回图片
    UIImageView * backimageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 44, 44)];
    backimageView.image=[UIImage imageNamed:@""];
    [bgview addSubview:backimageView];
    //添加手势
    UITapGestureRecognizer * trg=[[UITapGestureRecognizer alloc]initWithTarget:target action:action];
    [bgview addGestureRecognizer:trg];
    
    UIBarButtonItem * backBBI=[[UIBarButtonItem alloc]initWithCustomView:bgview];
    return backBBI;
    

}

//创建只带标题的BBI
+(UIBarButtonItem *)CreateTitleBBI:(NSString *)title target:(id)target action:(SEL)action
{
    UIBarButtonItem * titleBBI=[[UIBarButtonItem alloc]initWithTitle:title style:UIBarButtonItemStylePlain target:target action:action];
    titleBBI.tintColor=[UIColor whiteColor];
    return titleBBI;

}


//创建掌厨通用的BBI
+(UIBarButtonItem *)CreatePKBBIWithTitle:(NSString *)title image:(UIImage *)image target:(id)target action:(SEL)action{
    //设置承载图片和标题的容器
    UIView * ContentView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 40, 44)];
    //设置图片
    UIImageView * imageView=[[UIImageView alloc]initWithFrame:ContentView.frame];
    imageView.image=image;
    imageView.contentMode=UIViewContentModeScaleAspectFit;
    [ContentView addSubview:imageView];
    //设置标题
    UILabel * label=[[UILabel alloc]initWithFrame:CGRectMake(0, 30, ContentView.bounds.size.width, 14)];
    label.textAlignment=NSTextAlignmentCenter;
    label.textColor=[UIColor whiteColor];
    label.text=title;
    label.font=[UIFont systemFontOfSize:10];
    [ContentView addSubview:label];
    
    //设置点击事件
    UITapGestureRecognizer * tgr=[[UITapGestureRecognizer alloc]initWithTarget:target action:action];
    [ContentView addGestureRecognizer:tgr];
    UIBarButtonItem * bbi=[[UIBarButtonItem alloc]initWithCustomView:ContentView];
    return bbi;
    
}

//创建通用的背景颜色

+(UIColor *)CreateVCBackColor
{
    return [UIColor colorWithPatternImage:[UIImage imageNamed:@"homeView_bg"]];
}

//创建整个应用的主题色

+(UIColor *)CreateThemeColor
{
    return [UIColor colorWithRed:254/255.0f green:120/250.f blue:20/255.0f alpha:1.0];
    
}
//创建自定义的搜索框
+(UISearchController  *)UISearchController{
    //实例化一个搜索控制器
    //参数：需要提供一个展示结果的控制器
    UISearchController *searchCtl = [[UISearchController alloc] initWithSearchResultsController:nil];
    
    //根据内容自动匹配本身的大小
    [searchCtl.searchBar sizeToFit];
    //设置文字提示
    searchCtl.searchBar.placeholder = @"请输入关键字";
    //背景色
    searchCtl.searchBar.barTintColor = [UIColor cyanColor];
    //去掉变暗效果
    searchCtl.dimsBackgroundDuringPresentation = NO;
    
    return searchCtl;
}
@end
