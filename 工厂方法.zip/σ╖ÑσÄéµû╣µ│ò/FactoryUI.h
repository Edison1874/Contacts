//
//  FactoryUI.h
//  Kitchen
//
//  Created by fq on 15/11/5.
//  Copyright (c) 2015年 fangqian. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//UI工厂，用来产生重复出现的UI控件
@interface FactoryUI : NSObject
//创建首页上标题的BBI
+(UIBarButtonItem *)CreateProjectTitleBBI;

//创建用来调整位置的一个占位的BBI
+(UIBarButtonItem *)CreateSpaceBBIWidth:(CGFloat)width;

//创建应用返回的BBI
// @param  target 事件的目标对象  @param action 事件函数
+(UIBarButtonItem *)CreateBackBBIWithTarget:(id)target action:(SEL)action;

//创建只带标题的BBI
+(UIBarButtonItem *)CreateTitleBBI:(NSString *)title target:(id)target action:(SEL)action;


//创建掌厨通用的BBI
+(UIBarButtonItem *)CreatePKBBIWithTitle:(NSString *)title image:(UIImage *)image target:(id)target action:(SEL)action;

//创建通用的背景颜色

+(UIColor *)CreateVCBackColor;

//创建整个应用的主题色

+(UIColor *)CreateThemeColor;

//创建自定义的搜索框
+(UISearchController  *)UISearchController;



@end
